var i18n = {
	ui : {
		reload : '刷新页面有可能导致正在处理的业务数据丢失',
		loading : '加载中...',
		processing : '处理中...',
		livesuccess : '心跳检测正常',
		liveerror : '心跳检测失败'
	},
    
    message : {
    	updateheadimgsuccess : '头像更新完成',
    	savesuccess : '保存当前页面成功',
    	savefailed : '当前页面保存失败',
    	newwindow : '新建窗口',
    	create: '新增',
    	edit: '编辑',
    	remove: '删除',
    	ok: '确定',
    	cancel: '取消',
    	close: '关闭',
    	dialog: '对话框',
    	maximal: '最大化',
    	minimal: '最小化',
    	restore: '还原'
    }
};

/**
 * @module NGS
 * @author Kevin MOU
 * @lastModified 2015/07/03
 */
(function($) {

    /**
     * __系统顶级类：$F__，提供一些常用函数与方法
     * @class $F
     */
    $F = {
        version: '1.0.0 BETA',
        
        /**
         * 获得随机字符串
         * @method randomString
         * @param {integer} length 字符串长度
         * @return {string} 随机字符串
         */
        randomString : function (len) {
            len = len || 32;
            var $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789';
            var s = '';
            for (var i = 0; i < len; i++) {
                s += $chars.charAt(Math.floor(Math.random() * $chars.length));
            }
            return s;
        },
        
        /**
         * 随机获得一个[A-Z][0-9]的字符
         * @method randomChar
         * @param length {integer} 随机字符的个数，默认为1
         * @return {string} 随机字符串
         */
    	randomChar : function (length) {
    	    var $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    		var id = '';
			for (var i = 0; i < (length || 1); i++) {
				id += $chars.charAt(Math.floor(Math.random() * $chars.length));
			}
			return id;
    	},
    	
        /**
         * 获得一个不存在数据表中的6位ID
         * @method ID6Gen
         * @param key {string} SQLKEY
         * @return {string} 6位随机字符串
         */
    	ID6Gen : function(token, key){
    		var id = $F.randomChar(6);
    		if (key) {
        		$F.dataService('SystemDo2', {
        			data: $F.sqlbean(key, token, [id]),
        			async: false,
        			success : function(data) {
        				if (data.code < 1)
        					id = ID6Gen(key);
        			}
        		})
    		}
    		return id;
    	},

        /**
         * 数字格式化字符串方法
         *
         *	Format examples:
         *		formatNumber(0,'');
         * 		formatNumber(12432.21, '#,###');		// 货币分隔法
         * 		formatNumber(12432.21, '#,###.000#');	// 货币分割法，且小数点保留三位，不足三位小数补0, 尾数使用四舍五入
         * 		formatNumber(12432, '#,###.00');		// 货币分割法，且小数点保留两位，不足两位小数补0
         * 		formatNumber('12432.415', '#,###.0#');	// 货币分割法，且小数点保留一位, 尾数使用四舍五入
         * 		formatNumber('12345', '000000');		// 强制为6为数值，不足补0
         * 		formatNumber('22.90', '[$]##.##');		// 小数点保留不多于两位，且是美元$作为符号
         * 		formatNumber('0.124'. '#.00#%');		// 百分比转化，且小数点保留两位,不足两位小数补0, 尾数使用四舍五入
         *
         * @method formatNumber
         * @param {number || string} number 格式化对象，可以是数字或者字符串
         * @param {string} pattern 格式
         * @return {string} 格式化后的数字字符串
         */
        formatNumber : function(number, pattern) {
        	return String.formatNumber(number, pattern);
        },

        /**
         * 格式化字符串，通常用于进行字符串隐秘处理
         * @method formatString
         * @param {string} source 源字符串
         * @param {string} pattern 格式
         * @return {string} 格式化后的字符串
         *
         */
        formatString : function(vSourceString, vFormatString) {
            // 格式化字符
            var iIndex = 0, mReturnStr = "";
            var iSouceLen = vSourceString.length, iFormatLen = vFormatString.length;
            for (var i = 0; i < iFormatLen; i++) {
                var mStr = vFormatString.substr(i, 1);
                if (mStr == "#") {
                    if (iIndex < iSouceLen) {
                        mReturnStr = mReturnStr + vSourceString.substr(iIndex, 1);
                        iIndex++;
                    }
                } else if (mStr == "*") {
                    if (iIndex < iSouceLen) {
                        mReturnStr = mReturnStr + "*";
                        iIndex++;
                    }
                } else {
                    mReturnStr = mReturnStr + mStr;
                }
            }
            if (iIndex < iSouceLen) {
                mReturnStr += vSourceString.substr(iIndex);
            }
            return mReturnStr;
        },
        
        
        logGroup : function(c, e) {
        	if ($E.ws) {
                if(e && e.length > 30000){// vblocalproxy限制发送过去消息长度不能大于65534, 考虑到中文字符，所以只截取30000字符长度
                    e = e.substr(0, 30000) + '...';
                }
				var data = {
                    "module" : "log",
                    "category" : "NGSClient",
                    "loglevel" : 4,
                    "content" : ('[' + c + "] " + e)
                };
                $E.ws.send(JSON.stringify(data));
        	}
        	console.group('[' + c + "] " + e);
        	this.clientLogger.logToServer('[' + c + "] " + e, 'group');
            return this;
        },
        
        logGroupEnd : function(c, e, obj) {
        	if (c != undefined)
        		this.log(c, e, obj);
        	console.groupEnd();
        	this.clientLogger.logToServer('', 'groupEnd');
        },
        
        /**
         * 消息日志函数
         * @method log
         * @param {string} source 生产日志的对象
         * @param {string} event 日志消息内容
         * @chainable
         */
        log : function(c, e, obj) {
        	// LogOCX level:
        	// 1: system
        	// 2: error
        	// 3: warning
        	// 4: info
        	if (window.$E && $E.ws) {
                if(e && e.length > 30000){// vblocalproxy限制发送过去消息长度不能大于65534, 考虑到中文字符，所以只截取30000字符长度
                    e = e.substr(0, 30000) + '...';
                }
				var data = {
                    "module" : "log",
                    "category" : "NGSClient",
                    "loglevel" : 4,
                    "content" : ('[' + c + "] " + e)
                };
//    				if (obj)
//    					data.object = obj;
                $E.ws.send(JSON.stringify(data));
        	}
        	if (obj !== undefined)
        		console.log('[' + c + "] " + e, obj);
        	else
        		console.log('[' + c + "] " + e);
        	$F.clientLogger.logToServer('[' + c + "] " + e);
            return this;
        },
        
        /**
         * 本地日志批量发送到服务器上
         */
        clientLogger : {
        	enabled : false,
        	logServerUrl: '/clog/clientLogger',
        	logCacheSize : 100,
        	logCache : [],
        	spacer : '',
            logToServer : function(content, type){
            	if (this.enabled) {
            		type = type || 'debug';
            		if (type == 'groupEnd') {
            			if (this.spacer.length >= 2) {
            				this.spacer = this.spacer.substring(0, this.spacer.length - 2);
            			}
            		}
                	this.logCache.push(this.spacer + type + ' - ' + new Date().format('hh:mm:ss.S') + ' ' + content);
                	if (type == 'group') {
                		this.spacer += '  ';
                	}
                	if (this.logCache.length >= this.logCacheSize) {
                		$.ajax({
                			type : 'POST',
                			url : this.logServerUrl,
                			dataType : 'json',
                			data : JSON.stringify({
	                    		staffId: $E.staff.id,
	                    		token: $E.getActiveProject().token,
	                    		logs: this.logCache
                			}),
                			contentType : 'application/json;charset=UTF-8'
                    	});
                		this.logCache = [];
                	}
            	}
            }
        },

        /**
         * 错误消息日志函数
         * @method err
         * @param {string} source 生产日志的对象
         * @param {string} event 日志消息内容
         * @chainable
         */
        err : function() {
        	var name = 'Elite.NGS', cause = '', e;
        	if (arguments.length == 0)
        		return;
        	else if (arguments.length == 1)
        		e = arguments[0]
        	else if (arguments.length == 2) {
        		name = arguments[0];
        		e = arguments[1];
        	} else {
        		name = arguments[0];
        		cause = arguments[1];
        		e = arguments[2];
        	}
        	
        	console.error('[' + name + "] " + cause , e);
            return this;
        },

        
        

        /**
         * 错误消息对话框
         * @method alert
         * @param {string} message 消息内容
         * @param {callback} [callback] 关闭对话框后的回调方法
         * @chainable
         */
        alert : function(e, callback) {
        	alert(e);
        },
       

        /**
		 * 判断某个对象是否为undefined或者null
		 * 
		 * @method isNull
		 * @param {string}
		 *            object 对象
		 * @return {boolean}
		 */
        isNull : function(e) {
            return (e == undefined || e == null);
        },
        
    	copy : function(objA, objB, cover, exclude) {
    		if (objB == undefined || objB == null)
    			return objA
    			
    		for(var key in objB) {
    			if (exclude && exclude.contains(key.toLowerCase()))
    				continue;
    			
    			if (! objB.hasOwnProperty(key))
    				continue;
    			if (objA.hasOwnProperty(key) && !cover) 
    				continue;
    			objA[key] = objB[key];
    		}
    		return objA;
    	},


        /**
         * 判断某个对象是否为undefined或者null或者空字符串
         * @method isEmpty
         * @param {string} object 对象
         * @return {boolean}
         */
        isEmpty : function(e) {
            return (e == undefined || e == null || (typeof(e) == "string" && e.trim() == ""));
        },
        
        parseInt : function(e) {
        	e = parseInt(e);
        	if (isNaN(e))
        		return 0;
        	return e;
        },
        
        parseFloat : function(e) {
        	e = parseFloat(e);
        	if (isNaN(e))
        		return 0;
        	return e;
        },

        /**
         * 判断输入字符串是否是一个颜色字符串 #FFFFFF
         * @method isColorStr
         * @param {string} object 对象
         * @return {boolean}
         */
        isColorStr : function (e) {
            var reg = /^#?[0-9|a-f|A-F]{6}$/;
            return reg.test(e);
        },

        /**
         * 判断一个文件名后缀是不是属于图片类型
         * @param fileName
         */
        isImage : function(fileName) {
            if(fileName.lastIndexOf('.') > -1){
                fileName = fileName.substring(fileName.lastIndexOf('.') + 1);
            }
            var exts = ['PNG', 'JPG', 'JPEN', 'BMP'];
            for (var i = 0; i < exts.length; i++){
                var ext = exts[i];
                if($F.equalsIgnoreCase(fileName, ext)){
                    return true;
                }
            }
            return false;
        },

        /**
         * 忽略大小写进行比较
         * @param s {string} 比较源
         * @param t {string} 比较目标
         * @return {boolean}
         */
        equalsIgnoreCase : function(s, t){
            if(this.isEmpty(s) && this.isEmpty(t)){
                return true;
            }
            if(!this.isEmpty(s) && !this.isEmpty(t) && s.toLowerCase() == t.toLowerCase()){
                return true;
            }
            return false;
        },

        /**
         * 判断如果入参是null或者undefined或者空字符串,则返回空字符串，不然返回本身
         * @method parseEmpty
         * @param str {any} 入参对象
         * @return {any}
         */
        parseEmpty : function(str){
            if(this.isEmpty(str)){
                return "";
            }
            return str.toString();
        },
        
        /**
         * 字符串去空格，如果传入字符串为undefined或者null，返回空字符串
         * @method trimToEmpty
         * @param str {any} 入参对象
         * @return {any}
         */
        trimToEmpty : function(str){
            if(str && typeof(str) == "string"){
                return str.trim();
            }
            return "";
        },
        
        /**
         * 替换字符串中所有符合正则的字符，忽略大消息
         * @method replaceIngoreCase
         * @param s 原始字符串
         * @param t 需要替换的字符串
         * @param r 替换成的内容
         * @return {string} 返回替换后字符
         */
        replaceIngoreCase : function(s, t, r){
            if(s){
                return s.replace(new RegExp(t, "gi"), r);
            }
            return  s;
        },
        
        /**
         * 获取服务端当前时间 yyyy-MM-dd HH:mm:ss
         * @method getDbTime
         * @return {string}
         */
        getDbTime : function(){
            var mTime = $F.ajaxSync("GetDBTime",{});
            if (mTime && mTime.code>0)
            	return mTime.value;
            else
            	return new Date().format('yyyy-MM-dd hh:mm:ss');
        },

        /**
         * 判断字符串是否符合日期格式
         * @method isDate
         * @param val {string) 日期字符串
         * @return {boolean}
         */
        isDate : function(val) {
        	//在ie下，如果val是2016-02-01 13:47:57  new Date出来的valueOf是NaN，这里新增了这个parseDate方法用来识别日期
            var ret = false, d = this.parseDate(val);
            if(d) {
            	ret = !isNaN(d.valueOf());
            }
            return ret;
        },
        
        parseDate : function(t){
        	// 日期格式化
			if (t == '')
				return new Date();
			
			if ($.type(t) == 'date')
				return t;

			if ($.type(t) == 'number')
				return new Date(t);
			
			if ($.type(t) !== 'string') {
				return new Date();
			}
			
			var st = t.split(' '), format;
			if (st.length < 2) {
				var subt = st[0].split(':');
				if (subt.length > 1) {
					// 字符串为时间
					if (subt.length == 2)
						format = "H:i";
					else
						format = "H:i:s";
				}  else {
					// 字符串为日期
					format = "Y-m-d";
				}
			} else {
				// 字符串为完整日期时间
				var subt = t.trim().split(':');
				if (subt.length > 1) {
					// 字符串为时间
					if (subt.length == 2)
						format = "Y-m-d H:i";
					else {
						if (t.match(/^(\d{4})-(\d{1,2})-(\d{1,2}) (\d{1,2}):(\d{2}):(\d{2}).(\d{1,3})$/))
							format = Date.patterns.ISO8601LongestPattern;
						else
							format = Date.patterns.ISO8601LongPattern;
					}
				}  else {
					// 字符串为日期
					format = "Y-m-d H";
				}
			}
			// console.info(format);
			return Date.parseDate(t, format);
        },
        
        isSameDay : function(date1, date2) {
        	return date1.getYear() == date2.getYear()
        		&& date1.getMonth() == date2.getMonth()
        		&& date1.getDay() == date2.getDay();
        },
        
        betweenDays : function(date1, date2) {
        	var d1 = new Date(date1.getTime());
        	d1.setHours(0, 0, 0, 0);
        	var d2 = new Date(date2.getTime());
        	d2.setHours(0, 0, 0, 0);
        	// console.info((d2.getTime() - d1.getTime()))
        	return Math.floor((d2.getTime() - d1.getTime()) / (1000*60*60*24));
        },

        /**
         * 按单位修改时间
         * @method dateAdd
         * @param date {string} 需要修改的时间对象
         * @param c {string} 单位
         * @param v {integer} 修改的值
         * @return {date}
         */
        dateAdd : function(date, c, v){
            if(!(date instanceof Date)){
                date = $F.parseDate(date);
            }
            if(c == "day"){
                return new Date(date.getTime() + v * 24 * 60 * 60 * 1000);
            }
            if(c == "hour"){
                return new Date(date.getTime() + v * 60 * 60 * 1000);
            }
            if(c == "minute"){
                return new Date(date.getTime() + v * 60 * 1000);
            }
            if(c == "second"){
                return new Date(date.getTime() + v * 1000);
            }
        },

        dateAddFormat : function(date, c, v){
            return this.dateAdd(date, c, v).format();
        },

        

        /**
         * 创建单条SQL执行的JSON对象
         *
         *	// 该方法主要用于SystemDo2数据接口中进行SQL操作的快速封装
         *	// sql请求数据封装完成后的结构是：
         *	data : {
		 *		token: {string},
		 *		sqls: [
		 *			{
		 *				key: {string},
		 *				dbPool: {string},
		 *				params: {
		 *					C0: {any},
		 *					C1: {any},
		 *					C2: {any},
		 *					...
		 *				},
		 *				maxRow: {integer},
		 *				page: {integer}
		 *		]
		 *	}
		 *	// 请求方法实例：
		 *	var params = ['参数1', '参数2', '参数3', ...];
		 *	var sqlKey = 'SQL_KEY';
		 *	var sqlBean = $F.sqlbean(sqlKey, token, params);	// 使用系统默认最大行数，并且读取第1页（下标为0）
		 *	$F.dataService('SystemDo2', {
		 *		data: sqlBean,
		 *		success: function(data) {
		 *			// TODO: 处理数据，data的结构为标准XHR请求Result结构
		 *		},
		 *		fail: function(data) {
		 *		}
		 *	})
		 * 
		 * @method sqlbean
         * @param {string} key 数据服务方法名
         * @param {string} token 项目登录凭据
         * @param {list} params 数据服务的传参队列
         * @param {int} max 分页最大行数
         * @param {int} page 当前页码
         * @return {map} 数据服务请求的入参对象
         */
        sqlbean : function(key, token, params, max, page) {
        	return this.sqlbean2(key, token, '', params, max, page);
        },
        
        sqlbean2 : function(key, token, dbPool, params, max, page) {
            var dataRequest = {
                token : token,
                dbPool : dbPool,
                sqls : []
            };
            var map = {};
            $.each(params, function(i, v) {
                map['C' + (i + 1)] = v;
            });
            var sql = {
                    key : key,
                    params : map
                };
            if (max)
            	sql.maxRow = max;
            if (page)
            	sql.page = page;
            dataRequest.sqls.push(sql);
            return dataRequest;
        },

        /**
         * 创建请求树形结构数据的SQL执行的JSON对象
         *
         *	// 该方法主要用于SystemDo4（树形数据读取接口）中进行SQL操作的快速封装
         *	// sql请求数据封装完成后的结构是：
         *	data : {
		 *		token: {string},
		 *		sqls: [
		 *			{
		 *				key: {string},
		 *				params: {
		 *					C0: {any},
		 *					C1: {any},
		 *					C2: {any},
		 *					...
		 *				},
		 *				nodeId: {string},
		 *				parentId: {string}
		 *		]
		 *	}
		 *	// 请求方法实例：
		 *	var params = ['参数1', '参数2', '参数3', ...];
		 *	var sqlKey = 'SQL_KEY';
		 *	var nodeId = 'MENUITEM_GUID';	// 数据库中标识ID的字段名
		 *	var parentId = 'PARENT_GUID';	// 数据库中标识父节点ID的字段名
		 *	var sqlBean = $sqltree(sqlKey, token, params, nodeId, parentId);	// 树形结构数据的读取最大返回行数由系统接口自行决定
		 *	$F.dataService('SystemDo4', {
		 *		data: sqlBean,
		 *		success: function(data) {
		 *			// TODO: 处理数据，data的结构为标准XHR请求Result结构
		 *		},
		 *		fail: function(data) {
		 *		}
		 *	})
		 * 
		 * @method sqltree
         * @param {string} key 数据服务方法名
         * @param {string} token 项目登录凭据
         * @param {array} params 数据服务的传参
         * @param {string} nodeId 数据表中的记录ID字段名
         * @param {string} parentId 数据表中的记录父ID字段名
         * @return {map} 数据服务请求的入参对象
         */
        sqltree : function(key, token, params, nodeId, parentId, mustempty) {
            var map = {};
            $.each(params, function(i, v) {
                map['C' + (i + 1)] = v;
            });
            return {
                token : token,
                dbPool : '',
                sql : {
                    key : key,
                    params : map,
                    nodeId : nodeId,
                    parentId : parentId,
                    mustempty : mustempty
                }
            };
        },

        /**
		 * Ajax异步请求 // 使用示例 $F.ajaxAsync('MYMETHOD', { param1: 'xxx', param2: 100 }, function(data){ if (! $F.isNull(data)) { // 处理返回的数据，数据格式为标准XHR请求Result if (data.code > 0) { ... } else { ... } }
		 * else { // TODO：处理通讯请求失败 } } }
		 * 
		 * @method ajaxAsync
		 * @param {string}
		 *            host 数据服务地址，如果不以http开头，则表示使用系统配置的数据服务
		 * @param {string}
		 *            method 数据服务的方法名
		 * @param {object}
		 *            data 入参，接口使用PAYLOAD方式提交数据
		 * @param {callback}
		 *            callback 回调方法
		 */
        ajaxAsync : function(host, method, data, callback) {
        	if (callback === undefined)
        		return this.ajaxAsync($E.dataService.url, host, method, data);
        	
            this.dataService(host, method, {
                data : data,
                success : function(ajaxData) {
                    callback(ajaxData);
                },
                fail : function() {
                    callback();
                },
                error : function() {
                    callback();
                }
            });
        },

        /**
         * Ajax同步请求
         *
         * 	// 使用示例
         * 	var data = $F.ajaxSync('MYMETHOD',
         * 					{
		 * 						param1: 'xxx',
		 * 						param2: 100
		 * 					});
         * 	if ($F.isNull(data)) {
		 * 		if (data.code > 0){
		 * 			...
		 * 		} else {
		 * 			...
		 * 		}
		 * 	}
         *
         * @method ajaxSync
         * @param {string} host 数据服务地址，如果不以http开头，则表示使用系统配置的数据服务
         * @param {string} method 数据服务的方法名
         * @param {object} data 入参，接口使用PAYLOAD方式提交数据
         * @return {any} 数据请求结果JSON
         */
        ajaxSync : function(host, method, data) {
        	if (data === undefined)
        		return this.ajaxSync($E.dataService.url, host, method);
        	
            var result;
            this.dataService(host, method, {
                data : data,
                async : false,
                success : function(ajaxData) {
                    result = ajaxData;
                }
            });
            return result;
        },

        /**
         * 调用系统数据接口方法
         *
         * 	// 使用示例
         * 	$F.process(function() {
		 * 			$F.dataService('HOST', 'MY_METHOD', {
		 *					data: <any>   		// 请求提交的PAYLOAD数据
		 *					async : false,		// 使用同步处理
		 *					success: function(data) {
		 *						// TODO: 处理返回的数据
		 *					}
		 *				});
		 * 		}, '正在请求数据，请稍等...');
         * 	}
         *
         * @method dataService
         * @param {string} host 数据服务地址
         * @param {string} method 接口方法名
         * @param {object} options 入参的对象，包含data, async, success, fail, error
         * @param {string} [options.data] JSON字符串，使用JSON.stringify(data)进行转义
         * @param {boolean} [options.async] 是否异步执行，默认为true
         * @param {callback} [options.success] 执行完毕后的回调
         * @param {callback} [options.fail] 执行失败时的回调
         * @param {callback} [options.error] 执行发生错误时的回调
         */
        dsid : 0,
        dataService : function(host, method, opts) {
        	var a = this;
        	if (opts === undefined) {
        		return a.dataService($E.dataService.url, host, method);
        	}
        	
        	a.dsid ++;
        	var start = new Date(), dsid = a.dsid, sqlKeys = '';
        	// console.info('[DataService]', url, opts.data);
        	if (method == 'SystemDo2' || method == 'SystemDo1')
        		sqlKeys = (opts.data.sqls.length > 0 ? (opts.data.sqls.length > 1 ? (opts.data.sqls[0].key + '...') : opts.data.sqls[0].key) : '');
        	else if (method == 'SystemDo4')
        		sqlKeys = opts.data.sql.key;
        	else if (method == 'JSGenerateServlet4' || method == 'JSGenerateServlet2')
        		sqlKeys = opts.data.name;
        	else if (method == 'JSGenerateServlet')
        		sqlKeys = opts.data.clsName;
        	else if (method == 'SysCacheJSON')
        		sqlKeys = opts.data.Name;
        	else if (method == 'CacheDo2')
        		sqlKeys = (opts.data.sqls.length > 0 ? (opts.data.sqls.length > 1 ? (opts.data.sqls[0].cacheId + '...') : opts.data.sqls[0].cacheId) : '');
        	else if (method == 'CacheDoPubSql2')
        		sqlKeys = (opts.data.sqls.length > 0 ? (opts.data.sqls.length > 1 ? (opts.data.sqls[0].pubKey + '...') : opts.data.sqls[0].pubKey) : '');
        	else
        		sqlKeys == '';
        	console.info('%c[DataService - ' + dsid + '] ' + method + ' (' + sqlKeys + ')', 'color:#0d6b2b', opts.data)
        	
        	// opts.data.lang = $E.lang;
        	var data = JSON.stringify(opts.data), url;
        	if (opts.digest && $E.xhrDigest) {
        		var token = opts.data.token;
        		if (method == 'SysCacheJSON')
        			token = opts.data.Key;
        		if (! token)
        			throw new Error('报文签名失败');
        		
        		var digest = new MD5().digest(token.substring(opts.digest) + data);
        		url = a.getServiceMethod(host, method + '?MD5=' + digest); 
        		// console.info('签名报文, DIGEST= ' + url);
        	} else {
        		url = a.getServiceMethod(host, method);
        	}
        	
            Ajax.post({
            	headers: {
            		"ELITE-TAG" : "sp"
            	},
                url : url,
                data : data,
                contentType : 'application/json;charset=UTF-8',
                async : opts.async,
                success : function(data) {
                	var t = (new Date() - start);
                	if (t > 500)
                		console.log('%c[DataService - ' + dsid + ']' + method + ' (' + sqlKeys + '), took ' + t + '\'ms', "color:#ff0000;font-size: 1.5em");
                	// console.info(data);
                    if (data.code == -50001) {
                        a.err('Function - dataService', '请求异常 -' + data.message, url);
                        window.onbeforeunload = function() {
                        };
                        if ($E.device == 'mobile') {
                        	$E.reLogin();
                        	return;
                        } else {
                        	if (! $E.invalidState) {
                        		$E.invalidState = true;
                        		a.alert('请求异常 -' + data.message + '<br/>请重新登录', function() {
                                    if ($E.admin)
                                        location.href = $E.url + "/admin/logout";
                                    else
                                    	location.href = $E.url + '/logout';
                        		})
                        	}
                            return;
                        }
                    }
                    if ($.isFunction(opts.success))
                        opts.success(data);
                },
                fail : function(jqXHR, textStatus, errorThrown) {
                    if (jqXHR.status == 200) {
                    	a.err('Function - dataService', textStatus);
                    	//console.log(jqXHR.responseText)
                    	//console.log(JSON.parse(jqXHR.responseText))
                    	//console.error(errorThrown);
                    } else
                    	a.err('Function - dataService', '[STATUS:' + jqXHR.status + ']', textStatus);
                    if ($.isFunction(opts.fail)) {
                        opts.fail(jqXHR, textStatus, errorThrown);
                    }
                },
                always : function() {
                    if ($.isFunction(opts.always)) {
                        opts.always();
                    }
                }
            })
        },
        
        /*
         * 从配置中获得系统数据服务地址
         */
        getServiceMethod : function(serviceUrl, method) {
    		if (serviceUrl.toLowerCase().startWith('http')) {
    			//如果配置的地址和当前访问的地址的域是相同的，则可以直接用serviceUrl
    			var urlObj = Request.parseUrl(serviceUrl.toLowerCase());
    			if ((urlObj.scheme + ':') == location.protocol && urlObj.host == location.host){
    				if(location.protocol == 'https:' && urlObj.port == (location.port || 443) 
    						|| location.protocal == 'http:' && urlObj.port == (location.port || 80)){
    					return method? (serviceUrl + '/' + method) : serviceUrl;
    				}
    			}

    			// 通过代理中转插件服务
    			if (method)
    				serviceUrl = serviceUrl + '/' + method;
                return $E.url + '/proxy?url=' + encodeURIComponent(serviceUrl);
    		} else {
    			// 直接访问同一个JVM下的其他WebApp服务
    			return method? (serviceUrl + '/' + method) : serviceUrl;
    		}
        },

        /**
         * 整理SystemDo2接口返回的数据为JSON对象数组
         * @method makeJsonArray
         * @param data {object} 通过SystemDo2获取的数据对象
         * @param meta {boolean} 是否将列信息附加在队列上
         * @return {array} 标准JSON数据队列
         */
        makeJsonArray : function(data, meta) {
        	var cs = [];
        	if (data.count > 0) {
            	$.each(data.fields, function(i, field) {
            		var bean = {};
            		$.each(data.columns, function(k, column) {
            			bean[column] = ($.type(field[k]) == 'string') ? field[k].trim() : field[k];
            		});
            		cs.push(bean);
            	})
        	}
        	if (meta)
        		cs._columns = data.columns;
        	return cs;
        },
        
        /**
         * 整理SystemDo接口返回的数据为JSON对象对象
         * @method makeJsonBean
         * @param data {object} 通过SystemDo2获取的数据对象
         * @return {array} 标准JSON数据对象
         */
        makeJsonBean : function(data) {
        	var cs = this.makeJsonArray(data);
        	return cs.length > 0 ? cs[0] : null;
        },
        
        /**
         * 根据传递的主键和数据，直接构造出一个以主键值为key的map对象
         * @method makeJsonArrayMap
         * @param data {object} 通过SystemDo2获取的数据对象
         * @param primaryKey {string} 指定作为主键的字段
         * @return {object} 符合JSONSQL格式的对象Map
         */
        makeJsonArrayMap : function(data, primaryKey){
        	var cs = {};
        	if (data.count > 0) {
            	$.each(data.fields, function(i, field) {
            		var bean = {};
            		$.each(data.columns, function(k, column) {
            			bean[column] = ($.type(field[k]) == 'string') ? field[k].trim() : field[k];
            		});
            		cs[bean[primaryKey.toUpperCase()]] = bean;
            	})
        	}
        	return cs;
        },

        
        /**
         * 对通过SystemDo2接口请求返回的二维数组进行树形结构的整理
         *
         * 	// 属性结构数据示例，由于可能存在多个根节点的情况，因此属性结构数据本身是一个ARRAY
         * 	treedata : [
         * 		{
		 * 			id: {string},
		 * 			name: {string},
		 * 			pId: {string},
		 * 			folder: {boolean}
		 * 			data: {any},
		 * 			children: [...]
		 * 		}
         * 		...
         * 	]
         *
         * @method collectTree
         * @param {array} data SystemDO2接口返回的二维数组 {count:x, columns:[], fields:[]}
         * @param {string} idField 指定树结构'节点ID'对应的数据表字段名
         * @param {string} parentIdField 指定树结构'父节点ID'对应的数据表字段名
         * @param {string} descField 指定树结构'节点描述'对应的数据表字段名
         * @param {string} valueField 指定树结构'节点值'对应的数据表字段名
         * @return {array} 树形结构数据
         */
        collectTree : function(data, f_id, f_pid, f_desc, f_value) {
            var a = this, treedata = [], tmap = {},
                i_id = $F.getIndexOfColumns(data.columns, f_id),
                i_pid = $F.getIndexOfColumns(data.columns, f_pid),
                i_desc = $F.getIndexOfColumns(data.columns, f_desc),
                i_value = $F.getIndexOfColumns(data.columns, f_value);
            //console.log(i_id + ", " + i_pid + ", " + i_desc + ", " + i_value);
            $.each(data.fields, function(i, v){
                var node = {
                        id: v[i_id],
                        name: v[i_desc],
                        pId: v[i_pid],
                        children: [],
                        folder: false,
                        data: v[i_value]
                    }
            	tmap[node.id] = node;
            })
            for(var key in tmap) {
            	var node = tmap[key];
            	
                if (! node.pId)
                    treedata.push(node);
                else {
                    var parentNode = tmap[node.pId];
                    if (parentNode) {
                    	parentNode.folder = true;
                    	parentNode.children.push(node);
                    } else
                        a.err('Function - collectTree', '遗失的父节点，ID=' + node.id + ' PARENT:' + node.pId);
                }
            }
            
			console.log('CollectTree- ID:' + f_id + ', PID:' + f_pid + ', NAME:' + f_desc, treedata);
            return treedata;
        },

        /**
         * 获取字段序号，在SystemDo2接口中，获得的数据结构中字段名与数据是分离在两个不同的二维数组中，通过字段名获取相应的序号后才能在数据中取得数值。
         *
         * 	data : {
		 * 		count: {integer}
		 * 		columns: [....],
		 * 		fields: [[], [], ...]
		 * 	}
         *
         * @method getIndexOfColumns
         * @param {array} columns 字段名数组
         * @param {string} columnName 字段名
         * @return {integer} 字段序号，下标为0
         */
        getIndexOfColumns : function(columns, columnName) {
        	//console.log(columns);
        	//console.log(columnName);
            for(var i=0; i<columns.length; i++) {
                if (columns[i].toUpperCase() == columnName.toUpperCase())
                    return i;
            }
            return -1;
        },
        
        /**
         * 根据GUID获取树形结构中的节点数据
         * @method getTreeItemById
         * @param {treedata} treedata 树形结构数据
         * @param {string} id 查询的节点GUID
         * @return {treedata} 节点数据对象
         */
        getTreeItemById : function(treedata, id) {
        	var item;
        	if ($.type(treedata) == 'array') {
        		for(var i=0; i<treedata.length; i++) {
        			item = this.getTreeItemById(treedata[i], id);
        			if (item != null)
        				return item;
        		}
        		return null;
        	} else {
            	if (treedata.id == id)
            		return treedata;
            	
                var children = treedata.children;
                if (! children)
                    return null;

                for(var i=0; i<children.length; i++) {
                    item = this.getTreeItemById(children[i], id);
                    if (item != null)
                        return item;
                }
                return null;
        	}
        },
        
        getMapItemsCount : function(map) {
        	var key, c = 0;
        	for(key in map)
        		c ++;
        	return c;
        },
        
        firstMapEntry : function(map) {
        	for ( var key in map) {
        		return {
        			key: key,
        			value: map[key]
        		}
        	}
        }
    }
    
    
})(jQuery);
