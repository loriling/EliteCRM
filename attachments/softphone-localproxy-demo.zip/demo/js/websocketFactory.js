define([], function(){
	var wsFactory = function(wsAddr, wsOpen, wsClose, wsAsyncCallback, callback) {
		if (! wsAddr) {
			callback();
			return;
		}
		$F.log('Elite - initWebsocket', '初始化WebSocket在 ' + wsAddr);
		try {
			var ws = new WebSocket(wsAddr);
			ws.onmessage = function(e) {
				try {
					var data = JSON.parse(e.data);
					// $F.log('Elite - WebSocket', e.data);
					wsAsyncCallback(data);
				} catch (ex) {
					$F.err('Elite - Websocket', ex);
				}
			};

			ws.onclose = function() {
				$F.log('Elite', "WebSocket连接已关闭");
				wsClose();
				setTimeout(function() {
					wsFactory(wsAddr, wsOpen, wsClose, wsAsyncCallback);
				}, 1000 * 60);
			};

			ws.onerror = function(e) {
				$F.err('Elite', "WebSocket连接错误");
				if ($.isFunction(callback))
					callback();
			};

			ws.onopen = function(e) {
				wsOpen(ws);
				if ($.isFunction(callback))
					callback();
			};
		} catch (e) {
			console.error(e);
			if ($.isFunction(callback))
				callback();
		}
	}
	
	return wsFactory;
})

