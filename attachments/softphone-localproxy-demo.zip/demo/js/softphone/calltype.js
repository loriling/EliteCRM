/**
 * Created by Loriling on 2015/5/26.
 */
define(function(){
    return {
        UNKNOW : 0,
        INBOUND : 2,
        OUTBOUND : 3,
        SIMULAT_INBOUND : 4,
        PDS_OUTBOUND : 6
    }
});