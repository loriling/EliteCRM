/**
 * Created by Loriling on 2015/5/13.
 */
define(function(){
    return {
        LOGIN : 1,
        READY: 2,
        AUX: 3,
        ACW: 4,
        BUSY: 5,
        LOGOUT: 6,
        RINGING: 20,
        HOLD: 22,
        DIALING: 23,
        CONSULTING: 25,
        OFFHOOK: 24
    }
});