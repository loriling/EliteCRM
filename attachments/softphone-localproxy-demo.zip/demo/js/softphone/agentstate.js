/**
 * Created by Loriling on 2015/5/13.
 */
define(function(){
    return {
        EAS_UNKNOWN: 0,
        EAS_LOGOUT: 1,
        EAS_READY: 2,
        EAS_NOTREADY: 3,
        EAS_BUSY: 4,
        EAS_MAX: 5
    }
});
