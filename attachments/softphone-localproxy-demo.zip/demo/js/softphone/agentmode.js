/**
 * Created by Loriling on 2015/5/13.
 */
define(function(){
    return {
        EAM_UNKNOWN: 0,
        EAM_AUTOIN: 1,
        EAM_MANUALIN: 2,
        EAM_AUX: 3,
        EAM_ACW: 4,
        EAM_NOCALLDISCONNECT: 5,
        EAM_MAX: 6
    }
});