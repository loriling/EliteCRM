/**
 * Created by Loriling on 2015/5/13.
 */
define(function(){
    return {
        ECT_UNKNOWN: 0,
        ECT_RINGING: 1,
        ECT_TALKING: 2,
        ECT_HOLD: 3,
        ECT_DIALING: 4,
        ECT_TALKINGHOLD: 32,
        ECT_DIALINGHOLD: 34
    }
});