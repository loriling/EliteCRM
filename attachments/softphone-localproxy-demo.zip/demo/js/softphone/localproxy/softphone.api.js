"use strict";
define([], function(){
    var moduleName = "softphone";
	/**
	 * CallInfo类
	 */
	var CallInfo = function(callInfo){
        for(var k in callInfo){
            this[k] = callInfo[k];
        }
    };
    CallInfo.prototype = {
        getValue : function(key){
            return this[key.toLowerCase()];
        },
        setValue : function(key, value){
            this[key.toLowerCase()] = value;
        }
    };
    
    /**
     * Softphone类
     */
	var Softphone = function(){

    };
    Softphone.prototype = {
    	/**
    	 * 初始化软电话
    	 */
		initSoftphone : function(params, callback){
			//vblocalproxy版本软电话，无需在api中初始化
			callback && callback(true);
		},
        /**
         * 基本的动作调用，之后很多具体操作都会调用此基础方法
         * @param action 动作名字
         * @param param 相关参数
         * @param callback 回调函数
         */
        simpleActionCall : function(action, param, callback){
            var data = {
                action : action,
                param : param
            };
            $E.wsSend(moduleName, data, function(d){
                if($.isFunction(callback)){
                    callback(d);
                }
            }, {});
        },
        /**
         * 软电话的commonCall
         * @param callName 名字
         * @param callParas 参数
         * @param callback 回调
         */
        simpleCommonCall : function(callName, callParas, callback){
            var data = {
                action : "CommonCall",
                callName : callName,
                callParas : callParas
            };
            $E.wsSend(moduleName, data, function(d){
                if($.isFunction(callback)){
                    callback(d);
                }
            }, {});
        },
        /**
         * 获取软电话的callInfo
         * @param callback
         */
        getCallInfo : function(callback){
        	this.simpleActionCall('CallInfo', {}, function(d){
        		if($.isFunction(callback)){
        			var callInfo = new CallInfo(d);
                    callback(callInfo);
        		}
        	});
        },
        /**
         * 获取callStat
         * @param callback
         */
        getCallStat : function(callback){
            this.simpleActionCall("CallStat", {}, callback);
        },
        /**
         * 获取agentState和agentMode
         * @param callback
         */
        getAgentStateAndMode : function(callback){
            this.simpleActionCall("getAgentStateAndMode", {}, callback);
        },
        /**
         * 获取transferOnDialingHold属性值
         * @param callback
         */
        getTransferOnDialingHold : function(callback){
            this.simpleActionCall("getTransferOnDialingHold", {}, callback);
        },
        /**
         * 获取事件详细值
         * @param callback
         */
        getEvtDetail : function(callback){
            this.simpleActionCall("getEvtDetail", {}, callback);
        },
        /**
         * 获取事件
         * @param callback
         */
        getEvent : function(callback){
            this.simpleCommonCall("getevent", "", callback);
        },
        /**
         * 退出
         * @param callback
         */
        quit : function(callback){
            this.simpleActionCall("quit", {}, callback);
        },

        /**
         * 拨打电话
         * @param number 电话号码
         * @param sData 随路数据
         * @param callback 回调
         */
        makeCall : function(number, sData, callback){
            this.simpleActionCall("MakeCall", {
                number : number,
                sDataS : sData || ''
            }, callback);
        },
        /**
         * 挂断电话
         * @param callback
         */
        releaseCall : function(callback){
            this.simpleActionCall("ReleaseCall", {}, callback);
        },
        /**
         * 接起电话
         * @param callback
         */
        answerCall : function(callback){
            this.simpleActionCall("AnswerCall", {}, callback);
        },
        /**
         * 保持电话
         * @param callback
         */
        holdCall : function(callback){
            this.simpleActionCall("HoldCall", {}, callback);
        },
        /**
         * 接回电话
         * @param callback
         */
        retrieveCall : function(callback){
            this.simpleActionCall("RetrieveCall", {}, callback);
        },
        /**
         * 发起会议
         * @param number 会议号码
         * @param sData 随路数据
         * @param callback
         */
        initConference : function(number, sData, callback){
            this.simpleActionCall("InitConference", {
                number : number,
                sDataS : sData?sData:this.sDataS
            }, callback);
        },
        /**
         * 完成会议
         * @param callback
         */
        completeConference : function(callback){
            this.simpleActionCall("CompleteConference", {}, callback);
        },
        /**
         * 发起转接
         * @param number 转接号码
         * @param sData 随路数据
         * @param callback
         */
        initTransfer : function(number, sData, callback){
            this.simpleActionCall("InitTransfer", {
                number : number,
                sDataS : sData?sData:this.sDataS
            }, callback);
        },
        /**
         * 完成转接
         * @param callback
         */
        completeTransfer : function(callback){
            this.simpleActionCall("CompleteTransfer", {}, callback);
        },
        /**
         * 直接转
         * @param number 转接号码
         * @param sData 随路数据
         * @param callback
         */
        muteTransfer : function(number, sData, callback){
            this.simpleActionCall("MuteTransfer", {
                number : number,
                sDataS : sData?sData:this.sDataS
            }, callback);
        },
        
        /**
         * 单步转
         * @param number 转接号码
         * @param sData 随路数据
         * @param callback
         */
        singleStepTransfer : function(number, sData, callback) {
        	this.simpleActionCall("SingleStepTransfer", {
                number : number,
                sDataS : sData?sData:this.sDataS
            }, callback);
        },
        /**
         * 取消转接或者会议
         * @param callback
         */
        reconnect : function(callback){
            this.simpleActionCall("Reconnect", {}, callback);
        },
        /**
         * 置闲
         * @param callback
         */
        ready : function(callback){
            this.simpleCommonCall("button.click", "ready", callback);
        },
        /**
         * 置忙
         * @param callback
         */
        notReady : function(callback){
            this.simpleCommonCall("button.click", "notready", callback);
        },
        /**
         * 小休
         * @param callback
         */
        breaks : function(callback){
            this.simpleCommonCall("button.click", "break", callback);
        },
        /**
         * 静音
         * @param callback
         */
        mute : function(callback){
            this.simpleActionCall("Mute", {}, callback);
        },
        /**
         * 取消静音
         * @param callback
         */
        unMute : function(callback){
            this.simpleActionCall("UnMute", {}, callback);
        },
        /**
         * 通知软电话工作开始
         * @param workStatus
         * @param callback
         */
        notifyWorkStart : function(workStatus, callback){
            this.simpleActionCall("NotifyWorkStart", {
                workStatus : workStatus
            }, callback);
        },
        /**
         * 通知软电话工作结束
         * @param callback
         */
        notifyWorkEnd : function(callback){
            this.simpleActionCall("NotifyWorkEnd", {}, callback);
        },
        /**
         * 获取所有的随路数据
         * @param callback
         */
        allAttachDatas : function(callback){
            this.simpleActionCall("AllAttachDatas", {}, callback);
        },
        /**
         * 根据给定key获取随路数据
         * @param key
         * @param callback
         */
        attachData : function(key, callback){
            this.simpleActionCall("attachData", {
                key : key
            }, callback);
        },
        /**
         * 获取工号
         * @param callback
         */
        getAgentId : function(callback){
            this.simpleActionCall("getAgentId", {}, callback);
        },
        /**
         * 获取分机
         * @param callback
         */
        getExtension : function(callback){
            this.simpleActionCall("getExtension", {}, callback);
        },
        /**
         * 获取录音guid
         * @param callback
         */
        getRecordGuid : function(callback) {
            this.simpleActionCall("getRecordGuid", {}, callback);
        },
        
        /**
         * 获取录音相关信息
         * @param callback
         */
        getRecordInfo : function(callback) {
        	this.simpleActionCall("getRecordInfo", {}, callback);
        },
        /**
         * 强退
         * @param dn
         * @param agentId
         * @param callback
         */
        forceAgentLogout : function(dn, agentId, callback){
            this.simpleActionCall("ForceAgentLogout", {
                dn : dn,
                agentId : agentId
            }, callback);
        },
        /**
         * 强忙
         * @param dn
         * @param agentId
         * @param callback
         */
        forceAgentNotReady : function(dn, agentId, callback){
            this.simpleActionCall("ForceAgentNotReady", {
                dn : dn,
                agentId : agentId
            }, callback);
        },
        /**
         * 强闲
         * @param dn
         * @param agentId
         * @param callback
         */
        forceAgentReady : function(dn, agentId, callback){
            this.simpleActionCall("ForceAgentReady", {
                dn : dn,
                agentId : agentId
            }, callback);
        },
        /**
         * 监听
         * @param dn
         * @param callback
         */
        listen : function (dn, callback) {
            this.simpleActionCall("Listen", {
                dn : dn
            }, callback);
        },
        /**
         * 强拆
         * @param agentId
         * @param callback
         */
        intercept : function (agentId, callback){
            this.simpleActionCall("Intercept", {
                agentId : agentId
            }, callback);
        },
        /**
         * 强断
         * @param dn
         * @param callback
         */
        forceDisconnectAgentByDN : function (dn, callback){
            this.simpleActionCall("ForceDisconnectAgentByDN", {
                dn : dn
            }, callback);
        },
        /**
         * 板卡挂断
         * @param callback
         */
        forceHangUp : function (callback) {
            this.simpleActionCall("ForceHangup", {
                dn : dn
            }, callback);
        },
        /**
         * 强插
         * @param dn
         * @param callback
         */
        bargeIn : function (dn, callback){
            this.simpleActionCall("BargeIn", {
                dn : dn
            }, callback);
        },
        /**
         * 拦截
         * @param dn
         * @param agentId
         * @param callback
         */
        takeOver : function (dn, agentId, callback){
            this.simpleActionCall("TakeOver", {
                dn : dn,
                agentId : agentId
            }, callback);
        },
        /**
         * 暗语
         * @param dn
         * @param agentId
         * @param callback
         */
        coach : function (dn, agentId, callback){
            this.simpleActionCall("Coach", {
                dn : dn,
                agentId : agentId
            }, callback);
        },
        /**
         * 抓屏
         * @param ip
         * @param port
         * @param password
         * @param format
         * @param callback
         */
        flexMonitorScreen : function (ip, port, password, format, callback) {
            this.simpleActionCall("flexMonitorScreen", {
                ip : ip,
                port : port,
                password : password,
                format : format
            }, callback);
        },

        /**
         * 设置软电话自动应答属性
         * @param autoAnswer
         */
        setAutoAnswer : function(autoAnswer){
            this.simpleActionCall('setAutoAnswer', {
                autoAnswer : autoAnswer
            });
        },
        
        /**
         * 设置软电话自动添加号码头
         * @param autoPrefix
         */
        setAutoPrefix : function(autoPrefix){
            this.simpleActionCall('setAutoPrefix', {
            	autoPrefix : autoPrefix
            });
        },
        
        /**
         * 发送DTMF数据
         * @param number
         * @param callback
         */
        sendDTMF : function(number, callback){
            this.simpleActionCall('SendDTMF', {
                number : number
            }, callback);
        },
        
        /**
         * 给软电话注册vblocalproxy事件
         * @param callback 回调函数 接收参数data
         * 主要分为：
         * 1.data.type === "SCTIEvent" SCTIEvent事件
         *      包括了：data.msg == 'callstatechange' 电话状态变化
         *              data.msg == 'agentstatechange' 坐席状态变化
         *              data.msg == 'OnCallStart' 电话开始
         *              data.msg == 'OnCallEstablish' 电话接起
         *              data.msg.startWith('OnCallAction') 一些电话行为，包括了：MakeCall，InitTransfer，InitConference，MuteTransfer，SingleStepTransfer，PhoneNo
         *              data.msg == 'OnCallEnd' 电话结束
         *              data.msg == '73' notready
         *              data.msg == '74' EVT_DATAUPDATED
         *              data.msg == '23' mute
         *              data.msg == '24' unmute
         *
         * 2.data.type === "CTIEvent" CTIEvent事件
         *      CTIEvent相较于SCTIEvent来说，更底层，更全面，其中的参数也需要自己解析，解析过程可以自己尝试打印出内容查看后自行解析。主要用到了：
         *          var parsedEvent = parseEventDetail(data.EvtDetail);//解析事件详细内容
                    var evtObj = parsedEvent.evtObj;//事件内容
                    var attachObj = parsedEvent.attachObj;//随路数据
         *          evtObj["event"] == "9"  partydeleted
         *          evtObj["event"] == "22" partychanged
         *
         * 3.data.type === 'inited'
         *      电话初始化成功后事件
         */
        addEventListener : function(callback) {
        	var softphone = this;
        	//注册softphone事件 callback
            $E.wsAsyncQueue.push({
                token : $CONST.EVENT.WS_SOFTPHONE,
                persistence : true,	// 持久化回调方法，不需要删除
                callback : function(data, ev){
                    if (callback) {
                    	callback(data, ev);
                    }
                }
            });
        },
        
        /**
         * 软电话是否可用
         * @returns {Boolean}
         */
        available : function() {
        	if ($E.localWs) {
        		return true;
        	}
        	return false;
        },
        
        /**
         * 软电话登录
         * @param param 登录参数，是一个json对象
         *  {
                agentId : agentId, 		//工号
                extension : extension, 	//分机
                queue : queue,  		//队列
                position : position, 	//位置
                password : password  	//密码
            }
         * @param callback 登录结果回调，参数result: {true|false}
         */
        login : function(param, callback) {
        	var data = {
                action : "Login",
                param : param
            };
            $E.wsSend(moduleName, data, function(result){
                if (callback) {
                	callback(result);
                }
            }, {});
        },
        
        /**
         * 软电话登出
         * @param callback
         */
        logout : function(callback) {
        	this.simpleActionCall('Logout');
        },
        
        /**
         * 获取初始化ini配置信息
         * @param callback
         */
        getIniInfo : function(callback) {
        	this.simpleActionCall('getIniInfo', {}, callback);
        },
        
        /**
         * 发送消息给IVR
         * @param message
         * @param callback
         */
        sendIVRMessage : function(message, callback) {
        	this.simpleActionCall('SendIVRMessage', {
        		message: message
        	}, callback);
        },
        
        /**
         * 获取小修原因
         * @param callback
         */
        getReasonCode : function(callback) {
        	this.simpleActionCall('getReasonCode', {}, callback);
        }
    }
	
	return Softphone;
});


